select * from Customer_Data

select Gender, COUNT(Gender) as total_count,
Count(Gender)*100.0 / (Select COUNT(*) from Customer_Data) as Percentage
from Customer_Data 
Group by Gender

Select Contract, 
COUNT(Contract) as total_count,
Count(Contract)*1.0 / (Select COUNT(*) from Customer_Data) as Percentage
from Customer_Data
group by Contract

Select Customer_Status,
Count(Customer_Status) as Total_count, 
SUM(Total_Revenue) as Total_Rev,
SUM(Total_Revenue)/(Select SUM(Total_Revenue) from Customer_Data )*100 as Rev_percentage
from Customer_Data
group by Customer_Status

Select State, COUNT(State) as totalcount,
COUNT(State)*100 /(select count(*) from Customer_Data) as percentage
from Customer_Data
group by State 
order by percentage desc , totalcount desc

 Select distinct(Internet_Type), count(Internet_Type) as type_count from Customer_Data


